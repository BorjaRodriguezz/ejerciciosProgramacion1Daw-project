package examenes.examen20251024;

public class Ej04_NumerosCrecientesConsecutivos {

	public static void main(String[] args) {
		int num1 = 1234;
		int creciente;
		
		while (true) {
			
		}
		

	}

}
